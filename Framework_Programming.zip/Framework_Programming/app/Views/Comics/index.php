<?= $this->extend('Layout/H&F'); ?>

<?= $this->section('Content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <br>
            <h3 class="mt-2">My Favorite Comic List </h3>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Cover</th>
                        <th scope="col">Title</th>
                        <th scope="col">Author</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($Comics as $C) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><img src="/Images/<?= $C['cover']; ?>" alt="" class="Cover"></td>
                            <td><?= $C['title']; ?></td>
                            <td><?= $C['author']; ?></td>
                            <td>
                                <a href="" class="btn btn-success">Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>